import { useEffect, useRef, useState } from "react";

type TranslateBody = { text: string; source?: string; target?: string };

export default function VoiceTranslator() {
  const [input, setInput] = useState("");
  const [output, setOutput] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  // Voice recognition state
  const recogRef = useRef<any | null>(null);
  const [listening, setListening] = useState(false);
  const [interim, setInterim] = useState("");
  const [voiceLang, setVoiceLang] = useState("es-ES");

  // Live combined text (final + interim) and debounced translation trigger
  const combined = (input + (interim ? (input ? " " : "") + interim : "")).trim();
  const debouncedCombined = useDebounce(combined, 350);
  const xlateCtlRef = useRef<AbortController | null>(null);

  useEffect(() => {
    const text = debouncedCombined.trim();
    if (!text) {
      setOutput("");
      setError(null);
      xlateCtlRef.current?.abort();
      return;
    }
    setLoading(true);
    setError(null);
    xlateCtlRef.current?.abort();
    const ctl = new AbortController();
    xlateCtlRef.current = ctl;
    translate({ text, source: "es", target: "en" })
      .then((t) => setOutput(t))
      .catch((e: any) => {
        if (e?.name === "AbortError") return;
        const msg = typeof e?.message === "string" && e.message ? e.message : "Translation failed";
        setError(msg);
      })
      .finally(() => setLoading(false));
  }, [debouncedCombined]);

  useEffect(() => {
    return () => {
      try { recogRef.current?.stop?.(); } catch {}
      recogRef.current = null;
    };
  }, []);

  function startListening() {
    try {
      const SR: any = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      if (!SR) {
        setError("Voice recognition not supported in this browser.");
        return;
      }
      const recog = new SR();
      recog.lang = voiceLang || "es-ES";
      recog.continuous = true;
      recog.interimResults = true;
      recog.onstart = () => {
        setListening(true);
        setError(null);
      };
      recog.onerror = (e: any) => {
        const code = e?.error || "error";
        if (code === "not-allowed") {
          setError("Microphone permission denied. Allow mic access in your browser settings for this site.");
        } else if (code === "no-speech") {
          setError("No speech detected. Try again.");
        } else {
          setError("Voice recognition error");
        }
        setListening(false);
      };
      recog.onend = () => {
        setListening(false);
      };
      recog.onresult = (ev: any) => {
        let finalChunk = "";
        let interimChunk = "";
        for (let i = ev.resultIndex; i < ev.results.length; i++) {
          const res = ev.results[i];
          if (res.isFinal) finalChunk += res[0].transcript;
          else interimChunk += res[0].transcript;
        }
        if (finalChunk) {
          const sep = input && !input.endsWith(" ") ? " " : "";
          setInput((prev) => (prev + sep + finalChunk).trimStart());
        }
        setInterim(interimChunk);
      };
      recogRef.current = recog;
      recog.start();
    } catch (e) {
      setError("Failed to start voice recognition");
      setListening(false);
    }
  }

  function stopListening() {
    try { recogRef.current?.stop?.(); } catch {}
    setListening(false);
    setInterim("");
  }

  // Note: Setup guide button provides instructions for enabling mic on HTTP.

  return (
    <div className="mx-auto max-w-3xl p-6 rounded-xl border border-slate-200 bg-white shadow-sm">
      <h3 className="text-xl font-semibold mb-3">Voice Translation</h3>
      <p className="text-sm text-gray-600 mb-4">Speak Spanish and get live English translation.</p>

      <div className="mb-4 flex items-center gap-3">
        <label className="text-sm text-gray-700">Recognition language:</label>
        <select
          className="border rounded px-2 py-1 text-sm bg-white"
          value={voiceLang}
          onChange={(e) => setVoiceLang(e.target.value)}
        >
          <option value="es-ES">Spanish (Spain)</option>
          <option value="es-MX">Spanish (Mexico)</option>
          <option value="es-NI">Spanish (Nicaragua)</option>
          <option value="es-US">Spanish (US)</option>
          <option value="es-AR">Spanish (Argentina)</option>
          <option value="es-CO">Spanish (Colombia)</option>
        </select>
        {!listening ? (
          <button className="px-3 py-1 text-sm rounded bg-blue-600 text-white hover:bg-blue-700" onClick={startListening}>
            Start Mic
          </button>
        ) : (
          <button className="px-3 py-1 text-sm rounded bg-red-600 text-white hover:bg-red-700" onClick={stopListening}>
            Stop Mic
          </button>
        )}
        {listening && <span className="text-xs text-blue-700">Listening…</span>}
      </div>

      {error && <div className="mb-3 text-sm text-red-600">{error}</div>}

      <div className="grid gap-4 md:grid-cols-2">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Spanish (input)</label>
          <textarea
            className="w-full h-40 resize-y rounded border p-3 outline-none focus:ring-2 focus:ring-blue-500"
            placeholder="Speak or type Spanish here…"
            value={input}
            onChange={(e) => setInput(e.target.value)}
          />
          {interim && listening && <p className="mt-1 text-xs text-gray-500">{interim}</p>}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">English (translation)</label>
          <div className="min-h-[10rem] w-full rounded border p-3 bg-gray-50 whitespace-pre-wrap">
            {output || <span className="text-gray-400">Translation appears here</span>}
          </div>
          {loading && (
            <div className="mt-1 text-xs text-gray-500">Updating…</div>
          )}
        </div>
      </div>

      <p className="mt-3 text-xs text-gray-600">
        Tip: In Chrome, open <code>chrome://flags/#unsafely-treat-insecure-origin-as-secure</code>.
        Enable “Insecure origins treated as secure” and add your app’s full address (include protocol and port),
        for example <code>http://10.100.2.107:3001</code>. Save and restart Chrome.
      </p>
    </div>
  );
}

const API_BASE = (import.meta as any).env?.VITE_API_BASE || "";

async function translate(body: TranslateBody): Promise<string> {
  const resp = await fetch(`${API_BASE}/api/translate`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!resp.ok) {
    let message = `API error ${resp.status}`;
    try {
      const j = await resp.json();
      if (typeof j?.error === "string" && j.error) message = j.error;
    } catch (_) {}
    throw new Error(message);
  }
  const data = (await resp.json()) as { translated?: string };
  return data.translated ?? "";
}

function useDebounce<T>(value: T, delay: number): T {
  const [debounced, setDebounced] = useState(value);
  useEffect(() => {
    const id = setTimeout(() => setDebounced(value), delay);
    return () => clearTimeout(id);
  }, [value, delay]);
  return debounced;
}
