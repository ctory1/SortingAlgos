import express from "express";
import fetch from "node-fetch";
import cors from "cors";
import dotenv from "dotenv";
import { spawn } from "node:child_process";
import path from "node:path";
import { fileURLToPath } from "node:url";
dotenv.config();

console.log("Booting Translate API server...");

const app = express();
app.use(cors());
app.use(express.json());

// Choose a provider: "googletrans" | "google" | "openai"
const PROVIDER = process.env.TRANSLATE_PROVIDER || "googletrans";

function withTimeout(ms = 8000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), ms);
  return {
    signal: controller.signal,
    clear: () => clearTimeout(timer),
  };
}

app.post("/api/translate", async (req, res) => {
  try {
    const { text, source = "es", target = "en" } = req.body || {};
    if (!text || !text.trim()) return res.json({ translated: "" });

    let translated = "";
    const timeoutMs = Number(process.env.FETCH_TIMEOUT_MS) || 8000;
    const t = withTimeout(timeoutMs);

    if (PROVIDER === "googletrans") {
      // Use local Python googletrans (unofficial) for ES->EN or arbitrary pairs
      const isWin = process.platform === "win32";
      const cmd = process.env.PYTHON_BIN || (isWin ? "python" : "python3");
      const args = [PY_SCRIPT, "--stdin", "--raw", "--to", target];
      // Allow passing explicit source if desired
      if (source) args.push("--src", source);
      const child = spawn(cmd, args, {
        cwd: path.dirname(PY_SCRIPT),
        env: { ...process.env, PYTHONUTF8: "1" },
      });
      let stdout = "";
      let stderr = "";
      child.stdout.on("data", (d) => (stdout += d.toString("utf8")));
      child.stderr.on("data", (d) => (stderr += d.toString("utf8")));
      child.stdin.write(String(text));
      child.stdin.end();
      const killer = setTimeout(() => child.kill("SIGKILL"), timeoutMs);
      child.on("close", (code) => {
        clearTimeout(killer);
        if (code !== 0) {
          const msg = stderr && stderr.trim() ? stderr.trim() : `python_exit_${code}`;
          return res.status(502).json({ error: msg });
        }
        return res.json({ translated: stdout.trim() });
      });
      child.on("error", (err) => res.status(500).json({ error: `python_spawn_error: ${err.message}` }));
      return; // handled via callbacks

    } else if (PROVIDER === "google") {
      // Google Cloud Translate
      const key = process.env.GOOGLE_API_KEY;
      const url = `https://translation.googleapis.com/language/translate/v2?key=${key}`;
      const resp = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ q: text, source, target, format: "text" }),
        signal: t.signal,
      });
      if (!resp.ok) {
        const errText = await resp.text().catch(() => "");
        throw new Error(`Google Translate error ${resp.status}: ${errText}`);
      }
      const data = await resp.json();
      translated = data?.data?.translations?.[0]?.translatedText || "";

    } else if (PROVIDER === "openai") {
      // OpenAI (chat model for translation)
      const key = process.env.OPENAI_API_KEY;
      const resp = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${key}`,
        },
        body: JSON.stringify({
          model: process.env.OPENAI_MODEL || "gpt-4o-mini",
          messages: [
            { role: "system", content: "You are a translator. Translate strictly to English. No extra text." },
            { role: "user", content: text }
          ],
          temperature: 0.2,
        }),
        signal: t.signal,
      });
      if (!resp.ok) {
        const errText = await resp.text().catch(() => "");
        throw new Error(`OpenAI error ${resp.status}: ${errText}`);
      }
      const data = await resp.json();
      translated = data?.choices?.[0]?.message?.content?.trim() || "";
    }

    t.clear();
    res.json({ translated });
  } catch (e) {
    console.error("/api/translate failed:", e);
    const message = e?.name === "AbortError" ? "upstream timeout" : "translation failed";
    res.status(502).json({ error: message });
  }
});

// Simple health check for debugging
app.get("/health", (req, res) => {
  res.json({ ok: true, provider: PROVIDER });
});

const port = Number(process.env.PORT) || 3001;
const host = process.env.HOST || "127.0.0.1"; // Bind to IPv4 for reliability
const server = app.listen(port, host, () => {
  console.log(`Translate API running at http://${host}:${port} (${PROVIDER})`);
});
server.on("error", (err) => {
  console.error("Server failed to start:", err);
});

// --- English → Mexican Spanish (formal) via Python bridge ---
// Resolve absolute path to the Python script at repo root
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const PY_SCRIPT = path.resolve(__dirname, "..", "SpanishTranslator_MX.py");
const PY_SCRIPT_NI = path.resolve(__dirname, "..", "SpanishTranslator_NI.py");

// Serve built frontend from app/dist on the same port (always register; files may appear later)
const DIST_DIR = path.resolve(__dirname, "..", "app", "dist");
app.use(express.static(DIST_DIR));
// SPA fallback excluding API routes
app.get(/^\/(?!api\/).*/, (req, res, next) => {
  // Avoid intercepting missing static files before they exist
  const indexPath = path.join(DIST_DIR, "index.html");
  res.sendFile(indexPath, (err) => {
    if (err) return next();
  });
});

app.post("/api/translate-mx", async (req, res) => {
  try {
    const { text } = req.body || {};
    if (!text || !String(text).trim()) return res.json({ translated: "" });

  // Resolve Python executable: prefer env override; default to 'python' on Windows, 'python3' elsewhere
  const isWin = process.platform === "win32";
  const cmd = process.env.PYTHON_BIN || (isWin ? "python" : "python3");
    const args = [PY_SCRIPT, "--stdin"];
  const child = spawn(cmd, args, {
    cwd: path.dirname(PY_SCRIPT),
    env: { ...process.env, PYTHONUTF8: "1" },
  });

    let stdout = "";
    let stderr = "";
    child.stdout.on("data", (d) => (stdout += d.toString("utf8")));
    child.stderr.on("data", (d) => (stderr += d.toString("utf8")));

    // Write input and close stdin
    child.stdin.write(String(text));
    child.stdin.end();

    // Timeout safeguard
    const timeoutMs = Number(process.env.PY_BRIDGE_TIMEOUT_MS) || 12000;
    let responded = false;
    const safeSend = (sender) => {
      if (responded || res.headersSent) return;
      responded = true;
      try { sender(); } catch (_) {}
    };
    const timeout = setTimeout(() => {
      try { child.kill("SIGKILL"); } catch (_) {}
      safeSend(() => res.status(504).json({ error: "python_timeout" }));
    }, timeoutMs);

    child.on("close", (code) => {
      clearTimeout(timeout);
      if (code !== 0) {
        const msg = stderr && stderr.trim() ? stderr.trim() : `python_exit_${code}`;
        return safeSend(() => res.status(502).json({ error: msg }));
      }
      safeSend(() => res.json({ translated: stdout.trim() }));
    });

    child.on("error", (err) => {
      safeSend(() => res.status(500).json({ error: `python_spawn_error: ${err.message}` }));
    });
  } catch (e) {
    console.error("/api/translate-mx failed:", e);
    res.status(500).json({ error: "translation failed" });
  }
});

app.post("/api/translate-ni", async (req, res) => {
  try {
    const { text } = req.body || {};
    if (!text || !String(text).trim()) return res.json({ translated: "" });

    // Resolve Python executable: prefer env override; default to 'python' on Windows, 'python3' elsewhere
    const isWin = process.platform === "win32";
    const cmd = process.env.PYTHON_BIN || (isWin ? "python" : "python3");
    const args = [PY_SCRIPT_NI, "--stdin"];
    const child = spawn(cmd, args, {
      cwd: path.dirname(PY_SCRIPT_NI),
      env: { ...process.env, PYTHONUTF8: "1" },
    });

    let stdout = "";
    let stderr = "";
    child.stdout.on("data", (d) => (stdout += d.toString("utf8")));
    child.stderr.on("data", (d) => (stderr += d.toString("utf8")));

    // Write input and close stdin
    child.stdin.write(String(text));
    child.stdin.end();

    // Timeout safeguard
    const timeoutMs = Number(process.env.PY_BRIDGE_TIMEOUT_MS) || 12000;
    let responded = false;
    const safeSend = (sender) => {
      if (responded || res.headersSent) return;
      responded = true;
      try {
        sender();
      } catch (_) {}
    };
    const timeout = setTimeout(() => {
      try {
        child.kill("SIGKILL");
      } catch (_) {}
      safeSend(() => res.status(504).json({ error: "python_timeout" }));
    }, timeoutMs);

    child.on("close", (code) => {
      clearTimeout(timeout);
      if (code !== 0) {
        const msg = stderr && stderr.trim() ? stderr.trim() : `python_exit_${code}`;
        return safeSend(() => res.status(502).json({ error: msg }));
      }
      safeSend(() => res.json({ translated: stdout.trim() }));
    });

    child.on("error", (err) => {
      safeSend(() => res.status(500).json({ error: `python_spawn_error: ${err.message}` }));
    });
  } catch (e) {
    console.error("/api/translate-ni failed:", e);
    res.status(500).json({ error: "translation failed" });
  }
});
