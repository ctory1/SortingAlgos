// Import global CSS so Vite/Tailwind process and bundle it for static pages
import './index.css';

